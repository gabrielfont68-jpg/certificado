#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                        *\n");	
printf(" Programa 	GFS-57 - CENTRAL DO BRINQUEDO ELETRONICO               \n"
       "Um urso eletr�nico fala frases diferentes conforme a cor.\n"
       "Entrada: Verde, Amarelo ou Vermelho.\n"
       "Verde: Vamos brincar l� fora!\n"
       "Amarelo: Estou ficando com soninho...\n"
       "Vermelho: Estou com fome, hora do lanche!\n"
       "Outras cores: Cor desconhecida.\n\n");                                                                             
printf("\n********************************************************************************************************\n");

char cor[20];
    
    printf("Digite a cor que acendeu: ");
    scanf("%s", cor);
    
    if (strcmp(cor, "Verde") == 0 || strcmp(cor, "verde") == 0) {
        printf("O urso diz: \"Vamos brincar l� fora!\"\n");
    } else if (strcmp(cor, "Amarelo") == 0 || strcmp(cor, "amarelo") == 0) {
        printf("O urso diz: \"Estou ficando com soninho...\"\n");
    } else if (strcmp(cor, "Vermelho") == 0 || strcmp(cor, "vermelho") == 0) {
        printf("O urso diz: \"Estou com fome, hora do lanche!\"\n");
    } else {
        printf("Cor desconhecida. O urso apenas pisca as luzes.\n");
    }
}
