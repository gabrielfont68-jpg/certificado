#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno:Gabriel Fontenele Santos - RA 0025873                                                          *\n");	
printf(" Programa GFS-48 - MENU COM OPCAO DE SAIR               \n"
       "Um programa exibe um menu repetidamente.\n"
       "Op��o 1: mostrar mensagem 'Voc� escolheu a mensagem!'\n"
       "Op��o 2: sair do programa.\n"
       "O menu continua at� o usu�rio escolher sair.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

int opcao;

    do {
        printf("\nMenu\n");
        printf("1 - Mensagem\n");
        printf("2 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            printf("Voce escolheu a mensagem!\n");
        }

    } while (opcao != 2);

    printf("Programa encerrado.\n");
}
