#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                         *\n");	
printf(" Programa GFS-39 - VERIFICAR SE UM NUMERO E POSITIVO             \n"
        "Um sistema financeiro so aceita valores positivos\n"
       "para cadastro.\n"
       "O programa deve continuar pedindo numeros ate que\n"
       "o usuario digite um numero positivo.\n\n");                                                                                 
printf("\n********************************************************************************************************\n");

    int num;

    printf("Digite um numero positivo: ");
    scanf("%d", &num);

    while (num <= 0) {
        printf("Numero invalido. Digite um numero positivo: ");
        scanf("%d", &num);
    }

    printf("Numero aceito: %d\n", num);
}
