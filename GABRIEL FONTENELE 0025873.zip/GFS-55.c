#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                         *\n");	
printf(" Programa GFS-55 - MAIOR NUMERO ATE NEGATIVO               \n"
       "O programa l� n�meros positivos digitados pelo usu�rio.\n"
       "Ele para quando um n�mero negativo for digitado.\n"
       "Ao final, mostra o maior n�mero informado.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

float num, maior = 0;
    int primeiro = 1;
    
    printf("Digite notas positivas (negativo para parar):\n");
    
    while (1) {
        scanf("%f", &num);
        
        if (num < 0) break;
        
        if (primeiro || num > maior) {
            maior = num;
            primeiro = 0;
        }
    }
    
    if (!primeiro) {
        printf("O maior numero informado foi: %.2f\n", maior);
    } else {
        printf("Nenhum numero positivo foi informado.\n");
    }
}
