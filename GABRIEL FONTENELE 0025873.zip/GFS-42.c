#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                         *\n");	
printf(" Programa GFS-42 - QUANTIDADE DE NUMEROS IMPARES DIGITADOS               \n"
       "Uma pesquisa escolar precisa analisar numeros\n"
       "digitados pelos participantes.\n"
       "O programa deve pedir 10 numeros e informar\n"
       "quantos deles sao impares.\n\n");                                                                                
printf("\n********************************************************************************************************\n");
    int num, contador = 0, impares = 0;

    while (contador < 10) {
        printf("Digite um numero: ");
        scanf("%d", &num);

        if (num % 2 != 0) {
            impares++;
        }

        contador++;
    }

    printf("Quantidade de numeros impares: %d\n", impares);
}
