#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                          *\n");	
printf(" Programa GFS-36 - SOMA DE NUMEROS ATE DIGITAR ZERO             \n"
       "Um caixa simples de mercado precisa somar valores\n"
       "digitados pelo operador.\n"
       "O programa deve continuar recebendo numeros ate que\n"
       "o usuario digite 0 e, ao final, mostrar a soma total.\n\n");                                                                                 
printf("\n********************************************************************************************************\n");
    int num, soma = 0;

    printf("Digite numeros (0 para encerrar):\n");
    scanf("%d", &num);

    while (num != 0) {
        soma += num;
        scanf("%d", &num);
    }

    printf("Soma total = %d\n", soma);
}
