#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                         *\n");	
printf(" Programa GFS-53 - CONFIRMAR SAIDA COM 'S'                \n"
       "Ap�s cada operacao, o sistema pergunta se o usu�rio deseja sair.\n"
       "O menu continua at� que o usu�rio digite 's'.\n\n");                                                                              
printf("\n********************************************************************************************************\n");

char opcao;
    
    do {
        printf("\n=== MENU DE CADASTRO ===\n");
        printf("1 - Cadastrar usuario\n");
        printf("2 - Listar usuarios\n");
        printf("3 - Buscar usuario\n");
        printf("Digite 's' para sair.\n");
        
        printf("Escolha uma opcao ou 's' para sair: ");
        scanf(" %c", &opcao);
        
    } while (opcao != 's' && opcao != 'S');
    
    printf("Programa encerrado.\n");
}
