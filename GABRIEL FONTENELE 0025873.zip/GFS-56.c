#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                         *\n");	
printf(" Programa GFS-56 - MENU FAST-FOOD DIGITAL               \n"
       "Voc� est� programando um totem de autoatendimento.\n"
       "O cliente escolhe um n�mero de 1 a 4 correspondente ao combo.\n"
       "O sistema deve exibir o nome do combo e o valor:\n"
       "1: Combo Hamb�rguer + Batata + Refri - R$ 30,00\n"
       "2: Combo Pizza Brotinho + Refri - R$ 25,00\n"
       "3: Combo Salada + Suco Natural - R$ 22,00\n"
       "4: Combo Balde de Frango + Molho - R$ 35,00\n"
       "Outros valores: Op��o inv�lida!\n\n");                                                                              
printf("\n********************************************************************************************************\n");

int opcao;
    
    printf("=== TOTEM DE AUTOATENDIMENTO ===\n");
    printf("1 - Combo Hamburguer + Batata + Refri\n");
    printf("2 - Combo Pizza Brotinho + Refri\n");
    printf("3 - Combo Salada + Suco Natural\n");
    printf("4 - Combo Balde de Frango + Molho\n");
    printf("Escolha uma opcao: ");
    scanf("%d", &opcao);
    
    switch (opcao) {
        case 1:
            printf("Combo Hamb�rguer + Batata + Refri - R$ 30,00\n");
            break;
        case 2:
            printf("Combo Pizza Brotinho + Refri - R$ 25,00\n");
            break;
        case 3:
            printf("Combo Salada + Suco Natural - R$ 22,00\n");
            break;
        case 4:
            printf("Combo Balde de Frango + Molho - R$ 35,00\n");
            break;
        default:
            printf("Op��o inv�lida! Escolha de 1 a 4.\n");
    }
}
