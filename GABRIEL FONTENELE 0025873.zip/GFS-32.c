#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                         *\n");	
printf(" Programa GFS-32 - QUADRADO DOS NUMEROS DE 1 A 10           \n"
       "Um professor quer demonstrar o conceito de potencia ao\n"
       "quadrado para a turma.\n"
       "O programa deve mostrar o quadrado de cada numero\n"
       "de 1 a 10.\n\n");                                                                                  
printf("\n********************************************************************************************************\n");

int i;

    for (i = 1; i <= 10; i++) {
        printf("O quadrado de %d e: %d\n", i, i * i);
    }
}
