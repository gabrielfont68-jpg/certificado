#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                          *\n");	
printf(" Programa GFS-16 - Multiplo de 3 e/ou 5               \n"
       "Uma lanchonete criou uma promo��o especial. \n"
       "Se o numero do pedido for multiplo de 3, o cliente ganha um refrigerante. \n"
       "Se for multiplo de 5, ganha uma sobremesa. \n"
       "Se for multiplo dos dois, ganha os dois brindes. \n"
	   "O programa deve verificar o n�mero do pedido e informar qual premio o cliente ganhou.\n" );                                                                              
printf("\n********************************************************************************************************\n");


    int pedido;

    printf("Digite o numero do pedido: ");
    scanf("%d", &pedido);

    if (pedido % 3 == 0 && pedido % 5 == 0) {
        printf("Parabens! Voce ganhou um refrigerante e uma sobremesa.\n");
    } else if (pedido % 3 == 0) {
        printf("Parabens! Voce ganhou um refrigerante.\n");
    } else if (pedido % 5 == 0) {
        printf("Parabens! Voce ganhou uma sobremesa.\n");
    } else {
        printf("Nenhum brinde foi ganho.\n");
    }

    return 0;
}
