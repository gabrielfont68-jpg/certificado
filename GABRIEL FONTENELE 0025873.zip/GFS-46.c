#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                        *\n");	
printf(" Programa GFS-46 - CONTAR DE 1 A 10               \n"
        "Uma escola est� ensinando estruturas de repeti��o para iniciantes em programa��o.\n"
       "O programa deve imprimir os n�meros de 1 at� 10, um por linha,\n"
       "utilizando a estrutura do...while.\n\n");                                                                             
printf("\n********************************************************************************************************\n");

int numero = 1;

    do {
        printf("%d\n", numero);
        numero++;
    } while (numero <= 10);
}
