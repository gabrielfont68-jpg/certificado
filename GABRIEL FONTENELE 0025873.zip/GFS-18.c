#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                          *\n");	
printf(" Programa GFS-18 - LOGIN SIMPLES           \n"
       "Uma escola criou um sistema simples para acesso\n"
       "a biblioteca digital.\n\n"
       "O aluno deve informar usuario e senha corretos\n"
       "para entrar no sistema.\n\n"
       "O programa deve verificar se os dados digitados\n"
       "estao corretos e mostrar uma mensagem de acesso\n"
       "permitido ou negado.\n                                                                                   *");                                                                                    
printf("\n********************************************************************************************************\n");

	
    char usuario[20], senha[20];

    printf("Digite o usuario: ");
    scanf("%s", usuario);

    printf("Digite a senha: ");
    scanf("%s", senha);

    if (strcmp(usuario, "aluno") == 0 && strcmp(senha, "1234") == 0) {
        printf("Acesso permitido!\n");
    } else {
        printf("Acesso negado!\n");
    }










}
