#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
int main(){

printf("\n********************************************************************************************************\n");	
printf("\n*Aluno: Gabriel Fontenele Santos - RA 0025873                                                          *\n");	
printf(" Programa GFS-47 - TABUADA DE UM NUMERO               \n"
       "Um estudante quer praticar multiplica��o usando do...while.\n"
       "O programa deve receber um numero e exibir sua tabuada de 1 ate 10.\n\n");                                                                             
printf("\n********************************************************************************************************\n");

int numero;
    int contador = 1;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    do {
        printf("%d x %d = %d\n", numero, contador, numero * contador);
        contador++;
    } while (contador <= 10);
}
